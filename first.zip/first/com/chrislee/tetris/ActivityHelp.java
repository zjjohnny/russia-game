package com.chrislee.tetris;

import android.app.Activity;
import android.os.Bundle;

public class ActivityHelp extends Activity {

		public void onCreate(Bundle saved)
		{
			super.onCreate(saved);
			setContentView(R.layout.help);
		}

}
